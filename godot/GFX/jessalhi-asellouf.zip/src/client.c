#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define MAX_FILE 1024
#define MAX_NAME 256
#define MAX_REQUETE 1024

struct ip_port {
	struct sockaddr_in ipv4;
	struct sockaddr_in6 ipv6;
	int type_ipv6; // égal à 1 si ipv6 rempli 0 sinon
};

void raler(char* msg) {
  perror(msg);
  exit(1);
}

/*	Vérifie l'activité d'un descripteur pour permettre le recvfrom
	param desc Descripteur à vérifier
	Return 1 si libre 0 sinon
*/

int is_ready(int desc)
{
	fd_set ensemble;
	struct timeval delai;
	FD_ZERO(&ensemble);
	FD_SET(desc,&ensemble);
	delai.tv_sec = 1 ;
	delai.tv_usec = 0;
	if(select(desc +1 ,&ensemble ,NULL ,NULL,&delai)<0)
		return -1;
	return (FD_ISSET(desc,&ensemble)?1:0);
}

/* Lecture d'un fichier que l'on rempli dans un tableau en comptant le nombre de lignes.
   param *file Chemin fichier à lire
   param *tab Pointeur sur chaine à remplir
   param *nb Pointeur sur variable du nombre de ligne à remplir
*/

void lect_fichier(char* file, char *tab, int *nb){
	int fd;
	int n;

	if((fd = open(file, O_RDONLY)) == -1)
    	raler("open file");

    for(int i = 0; i < MAX_FILE; i++){
		if((n = read(fd, &(tab[i]), 1)) == -1) {
			close(fd);
			raler("read");
		}
		if (n == 0)
			break;
		if (tab[i] == '\n')
			*nb = *nb+1;
	}

	if(close(fd) == -1)
    	raler("close fd");
}

/* Construit un tableau de structure contenant toutes les ips d'une chaine contenant les serveurs racines.
   param *tab_racines Pointeur sur structure d'ips à remplir
   param *fichier_racines Chaine contenant la liste d'ip racines à extraire
   param nb_ips Nombre d'ips à extraire
*/

void build_tab_racines(struct ip_port *tab_racines, char *fichier_racines, int nb_ips){
	char temp[40];
	int j = 0;
	int k = 0;

	for (int i = 0; i < nb_ips; i++){
		tab_racines[i].type_ipv6 = 0;
		while (fichier_racines[j] != '|'){
			temp[k] = fichier_racines[j];
			k++;
			j++;
		}
		temp[k] = '\0';
		if(strstr(temp,":"))
			tab_racines[i].type_ipv6 = 1;
		j++;
		k = 0;

		if(tab_racines[i].type_ipv6 == 1 && inet_pton(AF_INET6, temp, &(tab_racines[i].ipv6.sin6_addr)) == -1) {
			free(tab_racines);	
			raler("inet_pton ipv6");
		} else if (inet_pton(AF_INET, temp, &(tab_racines[i].ipv4.sin_addr)) == -1) {
			free(tab_racines);
			raler("inet_pton ipv4");
		}

		while (fichier_racines[j] != '\n'){
			temp[k] = fichier_racines[j];
			k++;
			j++;
		}
		temp[k] = '\0';
		j++;
		k = 0;

		if(tab_racines[i].type_ipv6 == 1)
			tab_racines[i].ipv6.sin6_port = htons(atoi(temp));
		else
			tab_racines[i].ipv4.sin_port = htons(atoi(temp));
	}
}

/* Construit un tableau de structure contenant toutes les ips d'une requete serveur.
   param *tab_ip Pointeur sur structure d'ips à remplir
   param *message Chaines contenant la liste d'ip racines à extraire
*/

void build_tab_ip(struct ip_port *tab_ip, char *message){
	char temp[40];
	int j = 0;
	int k = 0;

	for (int i = 0; i < 20; i++){
		tab_ip[i].type_ipv6 = 0;
		while (message[j] != ','){
			j++;
		}
		j++;

		while (message[j] != ','){
			temp[k] = message[j];
			k++;
			j++;
		}
		temp[k] = '\0';
		if(strstr(temp,":"))
			tab_ip[i].type_ipv6 = 1;
		j++;
		k = 0;

		if(tab_ip[i].type_ipv6 == 1 && inet_pton(AF_INET6, temp, &(tab_ip[i].ipv6.sin6_addr)) == -1) {
			free(tab_ip);	
			raler("inet_pton ipv6");
		} else if (inet_pton(AF_INET, temp, &(tab_ip[i].ipv4.sin_addr)) == -1) {
			free(tab_ip);
			raler("inet_pton ipv4");
		}

		while (message[j] != '|' && message[j] != '\0'){
			temp[k] = message[j];
			k++;
			j++;
		}
		temp[k] = '\0';

		if(tab_ip[i].type_ipv6 == 1)
			tab_ip[i].ipv6.sin6_port = htons(atoi(temp));
		else
			tab_ip[i].ipv4.sin_port = htons(atoi(temp));

		if(message[j] != '\0')
			break;
		j++;
		k = 0;
	}
}

/* Cette fonction recursive est le coeur du programme.
   Elle prend un tableau d'ips racines au départ, on prend un serveur d'ip racine à laquelle on envoie 
   la "num_requete" ème requete à l'aide soit d'une socket ipv4 ou ipv6 selon le serveur destination.
   Si on reçoit une réponse alors on vérifie si c'est un succès ou échec, et on poursuit la recherche
   recursivement avec le nouveau tableau d'ips de serveurs destinations ou on s'arrete si on a deja trouvé 
   le nom de machine.
   param *sockfd4 Descripteur socket ipv4 si existe
   param *sockfd6 Descripteur socket ipv6 si existe
   param *tab Tableau d'ips et ports des serveurs destinations
   param **tab_nom Liste des noms de sites recherchés
   param num_requete Numéro de la requete à effectuer dans tab_nom
*/

int lancer_requete(int *sockfd4, int *sockfd6, struct ip_port* tab_racines, char **tab_noms, int num_requete){
	int i = 0, success = 0;
	socklen_t addrlen;
	struct timeval tv;
	static int identifiant = 1;
	char requete[MAX_REQUETE];
	static int size_req_init;
	while (!success){
		if(!tab_racines[i].type_ipv6) {
			struct sockaddr_in dest;
			dest.sin_family = AF_INET;
			dest.sin_port = tab_racines[i].ipv4.sin_port;
			dest.sin_addr = tab_racines[i].ipv4.sin_addr;
			addrlen = sizeof(struct sockaddr_in);

			for(int i = 0; i < 10; i++){
				gettimeofday (&tv, NULL);
				memset(requete, '\0', MAX_REQUETE);
				snprintf(requete, MAX_REQUETE, "%d|%ld%d|%s", identifiant, tv.tv_sec, tv.tv_usec, tab_noms[num_requete]);

				size_req_init = strlen(requete);

				printf("%s\n", requete);

				if(sendto(*sockfd4, requete, strlen(requete), 0, (struct sockaddr *)&dest, addrlen) == -1) {
					close(*sockfd4);
					raler("sendto");
				}
				identifiant++;

				if(is_ready(*sockfd4)){
					memset(requete, '\0', MAX_REQUETE);
					if(recvfrom(*sockfd4, requete, MAX_REQUETE, 0, (struct sockaddr *)&dest, &addrlen) == -1) {
						close(*sockfd4);
						raler("recvfrom");
					}
					printf("%s\n", requete);
					break;
				}
			}
		} else {
			struct sockaddr_in6 dest;
			dest.sin6_family = AF_INET6;
			dest.sin6_port = tab_racines[i].ipv6.sin6_port;
			dest.sin6_addr = tab_racines[i].ipv6.sin6_addr;
			addrlen = sizeof(struct sockaddr_in6);

			for(int i = 0; i < 10; i++){
				gettimeofday (&tv, NULL);
				memset(requete, '\0', MAX_REQUETE);
				snprintf(requete, MAX_REQUETE, "%d|%ld%d|%s", identifiant, tv.tv_sec, tv.tv_usec, tab_noms[num_requete]);

				printf("%s\n", requete);

				if(sendto(*sockfd6, requete, strlen(requete), 0, (struct sockaddr *)&dest, addrlen) == -1) {
					close(*sockfd6);
					raler("sendto");
				}
				identifiant++;

				if(is_ready(*sockfd6)){
				memset(requete, '\0', MAX_REQUETE);
				if(recvfrom(*sockfd6, requete, MAX_REQUETE, 0, (struct sockaddr *)&dest, &addrlen) == -1) {
					close(*sockfd6);
					raler("recvfrom");
				}
				printf("%s\n", requete);
				break;
				}
			}
		}

		// printf("%s\n", requete+size_req_init+2);

		if(strstr(requete, "|1|")){
			if(strstr(requete + (size_req_init + 2), tab_noms[i]))
				return 1;
			struct ip_port newtab[20];
			build_tab_ip(newtab, requete + (size_req_init + 2));

			success = lancer_requete(sockfd4, sockfd6, newtab, tab_noms, num_requete);
		} else if (i == 20){
			return 0;
		} else i++;
	}
	return success;
}

/*	On vérifie le nombre d'arguments pour lancer correctement le client.
	On découpe les fichiers racines et requetes dans des tableaux.
	On prépare les sockets IPv4 et IPv6 et on lance le coeur du programme.
	param argc
	param **argv (Chemin des fichiers à charger)
	return 0
*/

int main(int argc, char **argv) {
	if(argc != 3) {
		printf("Usage: fichier_racines <fichier_requetes>\n");
		exit(EXIT_FAILURE);
	}
	
	char fichier_racines[MAX_FILE];
	int nb_ips = 0;
	lect_fichier(argv[1], fichier_racines, &nb_ips);

	struct ip_port *tab_racines = malloc(nb_ips*sizeof(struct ip_port));
	
	build_tab_racines(tab_racines, fichier_racines, nb_ips);

	char **tab_noms = NULL;
	int nb_noms = 0;

	char fichier_noms[MAX_FILE];
	lect_fichier(argv[2], fichier_noms, &nb_noms);

	tab_noms = malloc(nb_noms * sizeof(char *));
	for(int i = 0; i < nb_noms; i++){
		tab_noms[i] = malloc(MAX_NAME * sizeof(char));
	}

	int j = 0;
	int k = 0;
	for (int i = 0; i < nb_noms; i++){
		while (fichier_noms[j] != '\n'){
			tab_noms[i][k] = fichier_noms[j];
			k++;
			j++;
		}
		j++;
		k = 0;
	}

	int sockfd4, sockfd6;
	socklen_t addrlen;
	struct sockaddr_in my_addr4;
	addrlen = sizeof(struct sockaddr_in);
	my_addr4.sin_family = AF_INET;
	my_addr4.sin_port = 3000;
	my_addr4.sin_addr.s_addr = htonl(INADDR_ANY);

	if((sockfd4 = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
		raler("socket");

	if(bind(sockfd4, (struct sockaddr *) &my_addr4, addrlen) == -1) {
		close(sockfd4);
		raler("bind");
	}
/*
	struct sockaddr_in6 my_addr6;
	addrlen = sizeof(struct sockaddr_in6);
	my_addr6.sin6_family = AF_INET6;
	my_addr6.sin6_port = 3000;
	if(inet_pton(AF_INET6, "::1/128", &my_addr6.sin6_addr) == -1)
        raler("inet_pton ipv6");
    //my_addr.sin6_addr.s6_addr = htons(IN6ADDR_ANY); Ne marche pas

	if((sockfd6 = socket(AF_INET6, SOCK_DGRAM, IPPROTO_UDP)) == -1)
		raler("socket");

	if(bind(sockfd6, (struct sockaddr *) &my_addr6, addrlen) == -1) {
		close(sockfd6);
		raler("bind");
	}
*/
	for(int i = 0; i < nb_noms; i++){
		lancer_requete(&sockfd4, &sockfd6, tab_racines, tab_noms, i);
	}

	close(sockfd4);
	//close(sockfd6);

	free(tab_racines);

	for(int i = 0; i < nb_noms; i++)
		free(tab_noms[i]);
	free(tab_noms);

	return 0;
}
