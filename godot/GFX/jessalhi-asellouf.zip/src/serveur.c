#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

#define MAX_FILE 1024
#define MAX_NAME 256
#define MAX_REQUETE 1024

struct nom_domaine {
	char domaine[MAX_NAME];
	char addr[40];
	char port[10];
};

void raler(char* msg) {
  perror(msg);
  exit(1);
}

int main(int argc, char **argv) {
	if(argc != 4) {
		printf("Usage: fichier_domaines addr port\n");
		exit(EXIT_FAILURE);
	}

	int fd1;
	char fichier_domaines[MAX_FILE];
	int n;
	int nb_domaines = 0;

	if((fd1 = open(argv[1], O_RDONLY)) == -1)
    	raler("open fichier_domaines");

    for(int i = 0; i < MAX_FILE; i++){
		if((n = read(fd1, &(fichier_domaines[i]), 1)) == -1) {
			close(fd1);
			raler("read");
		}
		if (n == 0)
			break;
		if (fichier_domaines[i] == '\n')
			nb_domaines++;
	}

	if(close(fd1) == -1)
    	raler("close fd1");

    struct nom_domaine *tab_domaines = malloc(nb_domaines*sizeof(struct nom_domaine));
    int j = 0;
	int k = 0;

	for (int i = 0; i < nb_domaines; i++){
		while (fichier_domaines[j] != '|'){
			tab_domaines[i].domaine[k] = fichier_domaines[j];
			k++;
			j++;
		}
		j++;
		k=0;
		while (fichier_domaines[j] != '|'){
			tab_domaines[i].addr[k] = fichier_domaines[j];
			k++;
			j++;
		}
		j++;
		k=0;
		while (fichier_domaines[j] != '\n'){
			tab_domaines[i].port[k] = fichier_domaines[j];
			k++;
			j++;
		}
		j++;
		k=0;
	}

	int sockfd;
	socklen_t addrlen;

	if(strstr(argv[2], ":") == NULL){
		if((sockfd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
			raler("socket");

		struct sockaddr_in my_addr;
		my_addr.sin_family = AF_INET;
		my_addr.sin_port = htons(atoi(argv[3]));
		addrlen = sizeof(struct sockaddr_in);

		if(inet_pton(AF_INET, argv[2], &my_addr.sin_addr) == -1)
			raler("inet_pton ipv4");

		if(bind(sockfd, (struct sockaddr *) &my_addr, addrlen) == -1) {
			close(sockfd);
			raler("bind");
		}

	} else {
		if((sockfd = socket(AF_INET6, SOCK_DGRAM, IPPROTO_UDP)) == -1)
			raler("socket");

		struct sockaddr_in6 my_addr;
		my_addr.sin6_family = AF_INET6;
		my_addr.sin6_port = htons(atoi(argv[3]));
		addrlen = sizeof(struct sockaddr_in6);

		if(inet_pton(AF_INET6, argv[2], &my_addr.sin6_addr) == -1)
			raler("inet_pton ipv6");

		if(bind(sockfd, (struct sockaddr *) &my_addr, addrlen) == -1) {
			close(sockfd);
			raler("bind");
		}
	}

	char requete[MAX_REQUETE];
	struct sockaddr dest;
	while(1){
		memset(requete,'\0', MAX_REQUETE);
		if(recvfrom(sockfd, requete, MAX_REQUETE, 0, &dest, &addrlen) == -1) {
			close(sockfd);
			raler("recvfrom");
		}
		printf("%s",requete);
		int success = 0;
		char serveurs_trouves[MAX_REQUETE];
		memset(serveurs_trouves, '\0', MAX_REQUETE);
		for(int i=0; i<nb_domaines; i++){
			if(strstr(requete, tab_domaines[i].domaine)){
				success = 1;
				snprintf(serveurs_trouves + strlen(serveurs_trouves), MAX_REQUETE - strlen(serveurs_trouves), "|%s,%s,%s", tab_domaines[i].domaine, tab_domaines[i].addr, tab_domaines[i].port);
			}
		}
		//printf("%s",requete);
		if(success)
			snprintf(requete + strlen(requete), MAX_REQUETE - strlen(requete), "|%d%s\n", success, serveurs_trouves);
		else
			snprintf(requete + strlen(requete), MAX_REQUETE - strlen(requete), "|%d\n", success);
		//printf("%s",requete);

		if(sendto(sockfd, requete, strlen(requete), 0, &dest, addrlen) == -1) {
			close(sockfd);
			raler("sendto");
		}
	}

	return 0;
}