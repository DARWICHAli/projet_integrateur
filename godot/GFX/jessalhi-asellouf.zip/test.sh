make

cd bin

./serveur ../input/serveur_racine 127.0.0.1 4443 &
./serveur ../input/serveur_racine 127.0.0.1 4444 &
./serveur ../input/serveur_racine 127.0.0.1 4445 &
./serveur ../input/serveur_com 127.0.0.1 4439 &
./serveur ../input/serveur_com 127.0.0.1 4440 &
./serveur ../input/serveur_fr 127.0.0.1 4441 &
./serveur ../input/serveur_fr 127.0.0.1 4442 &
./serveur ../input/serveur_example_fr 127.0.0.1 4451 &
./serveur ../input/serveur_example_fr 127.0.0.1 4452 &
./serveur ../input/serveur_site_com 127.0.0.1 4456 &
./serveur ../input/serveur_site_com 127.0.0.1 4457 &
./serveur ../input/serveur_test_com 127.0.0.1 4455 &

make

./client ../input/liste_racines ../input/liste_requetes

pkill serveur
pkill client
